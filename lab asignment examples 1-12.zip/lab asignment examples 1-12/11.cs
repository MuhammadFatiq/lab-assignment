List<int> intList = new List<int> (){10, 20, 30, 40, 50};
bool res = intList.TrueForAll(el => el%2 == 0);
