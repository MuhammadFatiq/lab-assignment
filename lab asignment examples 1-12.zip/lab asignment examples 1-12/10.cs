IList<int> intList = new List<int>{10, 20, 30,40};
intList.Remove(10);
intList.Remove(2);
