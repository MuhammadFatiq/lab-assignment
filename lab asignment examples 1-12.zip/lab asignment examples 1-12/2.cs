List<int> intList1 = new List<int>();
        intList1.Add(10);
        intList1.Add(20);
        intList1.Add(30);
        intList1.Add(40);

intList1<int intList2 = new List<int>();
intList2.AddRange(intList1);
