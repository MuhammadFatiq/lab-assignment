Ilist<int> intList = new LIst<int>{10, 20, 30, 40 ,50} ;
intList.Insert(1,11);
foreach (var el in intList)
Console.Write(el);
